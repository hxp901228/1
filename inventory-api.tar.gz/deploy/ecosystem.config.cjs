module.exports = {
  apps: [
    {
      name: 'inventory-api',
      cwd: '/opt/inventory',
      script: 'node_modules/tsx/dist/cli.mjs',
      args: 'api/server.ts',
      instances: 1,
      autorestart: true,
      max_memory_restart: '300M',
      env: {
        NODE_ENV: 'production',
        PORT: 3001,
        // 上线前务必改成随机长字符串，否则任何人都能伪造登录 token
        JWT_SECRET: 'CHANGE_ME_TO_A_RANDOM_SECRET',
      },
    },
  ],
}
