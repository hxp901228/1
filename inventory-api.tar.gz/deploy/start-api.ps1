$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$node = 'C:\Users\Administrator\nodejs\node-v20.18.1-win-x64\node.exe'
$tsx = Join-Path $root 'node_modules\tsx\dist\cli.mjs'

Start-Process -FilePath $node `
  -ArgumentList $tsx, 'api\server.ts' `
  -WorkingDirectory $root `
  -WindowStyle Hidden `
  -RedirectStandardOutput (Join-Path $root 'api_server.out.log') `
  -RedirectStandardError (Join-Path $root 'api_server.err.log')
