import Database from 'better-sqlite3'
import path from 'path'
import { fileURLToPath } from 'url'
import bcrypt from 'bcryptjs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const dbPath = path.join(__dirname, '..', 'data', 'inventory.db')

export const db = new Database(dbPath)

db.pragma('journal_mode = WAL')
db.pragma('foreign_keys = ON')

// 写入操作日志
export function logOperation(params: {
  operationType: string
  productId: number
  productName: string
  spec: string | null
  quantity: number
  stockBefore: number
  stockAfter: number
  operatorId: number
  operatorName: string
  source?: string | null
  purpose?: string | null
  customerName?: string | null
  remark?: string | null
  refId?: number | null
}) {
  db.prepare(
    `INSERT INTO operation_logs
      (operation_type, product_id, product_name, spec, quantity, stock_before, stock_after,
       operator_id, operator_name, source, purpose, customer_name, remark, ref_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    params.operationType,
    params.productId,
    params.productName,
    params.spec || null,
    params.quantity,
    params.stockBefore,
    params.stockAfter,
    params.operatorId,
    params.operatorName,
    params.source || null,
    params.purpose || null,
    params.customerName || null,
    params.remark || null,
    params.refId || null
  )
}

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'employee',
      disabled INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      image TEXT,
      spec TEXT,
      batch_no TEXT,
      production_date TEXT,
      expiry_date TEXT,
      stock INTEGER NOT NULL DEFAULT 0,
      source TEXT,
      remark TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS inbounds (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL,
      source TEXT,
      remark TEXT,
      operator_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products(id),
      FOREIGN KEY (operator_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS claims (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      purpose TEXT,
      customer_name TEXT,
      member_no TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS claim_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      claim_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL,
      FOREIGN KEY (claim_id) REFERENCES claims(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS outbounds (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      claim_id INTEGER,
      remark TEXT,
      operator_id INTEGER NOT NULL,
      type TEXT NOT NULL DEFAULT 'claim',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (claim_id) REFERENCES claims(id),
      FOREIGN KEY (operator_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS outbound_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      outbound_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL,
      revoked INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (outbound_id) REFERENCES outbounds(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS operation_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      operation_type TEXT NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      spec TEXT,
      quantity INTEGER NOT NULL,
      stock_before INTEGER NOT NULL,
      stock_after INTEGER NOT NULL,
      operator_id INTEGER NOT NULL,
      operator_name TEXT NOT NULL,
      source TEXT,
      purpose TEXT,
      customer_name TEXT,
      remark TEXT,
      ref_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products(id),
      FOREIGN KEY (operator_id) REFERENCES users(id)
    );
  `)

  // 迁移：为已有 products 表添加 spec 列
  const cols = db.prepare("PRAGMA table_info(products)").all() as { name: string }[]
  const hasSpec = cols.some((c) => c.name === 'spec')
  if (!hasSpec) {
    db.exec('ALTER TABLE products ADD COLUMN spec TEXT')
  }

  // 迁移：为已有 products 表添加 deleted 列（软删除）
  const hasDeleted = cols.some((c) => c.name === 'deleted')
  if (!hasDeleted) {
    db.exec('ALTER TABLE products ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0')
  }

  // 迁移：为已有 users 表添加 phone 列
  const userCols = db.prepare("PRAGMA table_info(users)").all() as { name: string }[]
  const hasPhone = userCols.some((c) => c.name === 'phone')
  if (!hasPhone) {
    db.exec('ALTER TABLE users ADD COLUMN phone TEXT')
  }

  // 迁移：将旧的单图字符串转为 JSON 数组格式
  const products = db.prepare('SELECT id, image FROM products').all() as { id: number; image: string | null }[]
  const updateImg = db.prepare('UPDATE products SET image = ? WHERE id = ?')
  for (const p of products) {
    if (!p.image) continue
    let parsed: string[] | null = null
    try {
      const arr = JSON.parse(p.image)
      if (Array.isArray(arr)) parsed = arr
    } catch {
      // 旧格式：单个字符串路径
    }
    if (!parsed) {
      updateImg.run(JSON.stringify([p.image]), p.id)
    }
  }

  const userCount = (db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number }).count
  if (userCount === 0) {
    const adminHash = bcrypt.hashSync('admin123', 10)
    const devHash = bcrypt.hashSync('dev123', 10)
    db.prepare(
      `INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?), (?, ?, ?, ?)`
    ).run(
      'admin', adminHash, '系统管理员', 'admin',
      'developer', devHash, '开发者', 'developer'
    )
  }

  const productCount = (db.prepare('SELECT COUNT(*) as count FROM products').get() as { count: number }).count
  if (productCount === 0) {
    const insertProduct = db.prepare(
      `INSERT INTO products (name, image, spec, batch_no, production_date, expiry_date, stock, source, remark)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    const products = [
      ['医用外科口罩', null, '50只/盒 蓝色', 'MASK202501', '2025-01-15', '2027-01-14', 500, '厂家A直供', '成人款'],
      ['一次性手套', null, 'M码 100只/盒', 'GLO202502', '2025-02-10', '2027-02-09', 300, '厂家B供应', 'M码'],
      ['酒精消毒液', null, '500ml/瓶', 'ALC202503', '2025-03-01', '2026-03-01', 150, '厂家C采购', '500ml装'],
      ['电子体温计', null, '红外额温枪', 'THM202501', '2025-01-20', '2028-01-19', 80, '厂家D直供', '电子款'],
      ['创可贴', null, '100片/盒 防水型', 'BND202502', '2025-02-15', '2027-02-14', 1000, '厂家E供应', '100片/盒'],
    ]
    for (const p of products) {
      insertProduct.run(...p)
    }
  }
}
