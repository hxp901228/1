import { Router, type Response } from 'express'
import { db } from '../db.js'
import { authMiddleware, requireAdmin, type AuthRequest } from '../middleware/auth.js'

const router = Router()

router.use(authMiddleware, requireAdmin)

router.get('/', (req: AuthRequest, res: Response): void => {
  const type = (req.query.type as string) || 'all'
  const inbounds = type === 'all' || type === 'inbound'
    ? db.prepare(`
        SELECT 'inbound' as type, i.id, i.created_at, i.quantity, i.source as channel, i.remark,
               p.name as product_name, p.spec, p.image, p.batch_no, u.name as operator_name, null as purpose, null as customer_name
        FROM inbounds i
        JOIN products p ON i.product_id = p.id
        JOIN users u ON i.operator_id = u.id
      `).all()
    : []

  const outbounds = type === 'all' || type === 'outbound'
    ? db.prepare(`
        SELECT 'outbound' as type, oi.id, o.created_at, oi.quantity, null as channel, o.remark,
               p.name as product_name, p.spec, p.image, p.batch_no, u.name as operator_name, c.purpose, c.customer_name
        FROM outbound_items oi
        JOIN outbounds o ON oi.outbound_id = o.id
        JOIN products p ON oi.product_id = p.id
        JOIN users u ON o.operator_id = u.id
        LEFT JOIN claims c ON o.claim_id = c.id
        WHERE oi.revoked = 0
      `).all()
    : []

  const records = [...inbounds, ...outbounds].sort(
    (a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  )
  res.json({ success: true, data: records })
})

export default router
