import { Router, type Response } from 'express'
import { db, logOperation } from '../db.js'
import { authMiddleware, requireAdmin, type AuthRequest } from '../middleware/auth.js'

const router = Router()

router.use(authMiddleware)

router.get('/', (req: AuthRequest, res: Response): void => {
  const isAdmin = req.user!.role === 'admin' || req.user!.role === 'developer'
  let rows
  if (isAdmin) {
    rows = db.prepare(`
      SELECT c.*, u.name as user_name
      FROM claims c
      JOIN users u ON c.user_id = u.id
      ORDER BY c.created_at DESC
    `).all()
  } else {
    rows = db.prepare(`
      SELECT c.*, u.name as user_name
      FROM claims c
      JOIN users u ON c.user_id = u.id
      WHERE c.user_id = ?
      ORDER BY c.created_at DESC
    `).all(req.user!.id)
  }
  for (const claim of rows as any[]) {
    claim.items = db.prepare(`
      SELECT ci.*, p.name as product_name, p.image, p.spec, p.stock as current_stock
      FROM claim_items ci
      JOIN products p ON ci.product_id = p.id
      WHERE ci.claim_id = ?
    `).all(claim.id)
  }
  res.json({ success: true, data: rows })
})

router.post('/', (req: AuthRequest, res: Response): void => {
  const { items, purpose, customerName, memberNo } = req.body
  if (!items || !Array.isArray(items) || items.length === 0) {
    res.status(400).json({ success: false, error: '请选择申领产品' })
    return
  }
  for (const item of items) {
    if (!item.productId || !item.quantity || item.quantity <= 0) {
      res.status(400).json({ success: false, error: '申领数量不合法' })
      return
    }
    const product = db.prepare('SELECT stock FROM products WHERE id = ?').get(item.productId) as any
    if (!product) {
      res.status(400).json({ success: false, error: '产品不存在' })
      return
    }
  }

  const tx = db.transaction(() => {
    const result = db.prepare(
      'INSERT INTO claims (user_id, purpose, customer_name, member_no) VALUES (?, ?, ?, ?)'
    ).run(req.user!.id, purpose || null, customerName || null, memberNo || null)
    const claimId = result.lastInsertRowid
    const stmt = db.prepare(
      'INSERT INTO claim_items (claim_id, product_id, quantity) VALUES (?, ?, ?)'
    )
    for (const item of items) {
      stmt.run(claimId, item.productId, item.quantity)
    }
  })
  tx()
  res.json({ success: true })
})

router.put('/:id/cancel', (req: AuthRequest, res: Response): void => {
  const id = Number(req.params.id)
  const claim = db.prepare('SELECT * FROM claims WHERE id = ?').get(id) as any
  if (!claim) {
    res.status(404).json({ success: false, error: '申领单不存在' })
    return
  }
  if (claim.user_id !== req.user!.id) {
    res.status(403).json({ success: false, error: '只能撤销自己的申领单' })
    return
  }
  if (claim.status !== 'pending') {
    res.status(400).json({ success: false, error: '只有待审核的申领单可以撤销' })
    return
  }
  db.prepare("UPDATE claims SET status = 'cancelled' WHERE id = ?").run(id)
  res.json({ success: true })
})

router.put('/:id/items/:itemId/remove', requireAdmin, (req: AuthRequest, res: Response): void => {
  const itemId = Number(req.params.itemId)
  const claimId = Number(req.params.id)
  db.prepare('DELETE FROM claim_items WHERE id = ? AND claim_id = ?').run(itemId, claimId)
  const remaining = (db.prepare('SELECT COUNT(*) as count FROM claim_items WHERE claim_id = ?').get(claimId) as any).count
  if (remaining === 0) {
    db.prepare("UPDATE claims SET status = 'cancelled' WHERE id = ?").run(claimId)
  }
  res.json({ success: true })
})

router.post('/:id/confirm', requireAdmin, (req: AuthRequest, res: Response): void => {
  const id = Number(req.params.id)
  const { remark } = req.body
  const claim = db.prepare('SELECT * FROM claims WHERE id = ?').get(id) as any
  if (!claim) {
    res.status(404).json({ success: false, error: '申领单不存在' })
    return
  }
  if (claim.status !== 'pending') {
    res.status(400).json({ success: false, error: '该申领单已处理' })
    return
  }
  const items = db.prepare(`
    SELECT ci.*, p.name as product_name, p.spec, p.stock
    FROM claim_items ci
    JOIN products p ON ci.product_id = p.id
    WHERE ci.claim_id = ?
  `).all(id) as any[]
  if (items.length === 0) {
    res.status(400).json({ success: false, error: '申领单没有产品' })
    return
  }

  const operator = db.prepare('SELECT name FROM users WHERE id = ?').get(req.user!.id) as { name: string } | undefined

  const tx = db.transaction(() => {
    const result = db.prepare(
      'INSERT INTO outbounds (claim_id, remark, operator_id, type) VALUES (?, ?, ?, ?)'
    ).run(id, remark || null, req.user!.id, 'claim')
    const outboundId = result.lastInsertRowid
    const stmt = db.prepare(
      'INSERT INTO outbound_items (outbound_id, product_id, quantity) VALUES (?, ?, ?)'
    )
    for (const item of items) {
      stmt.run(outboundId, item.product_id, item.quantity)
      db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(item.quantity, item.product_id)

      logOperation({
        operationType: 'outbound',
        productId: item.product_id,
        productName: item.product_name,
        spec: item.spec,
        quantity: item.quantity,
        stockBefore: item.stock,
        stockAfter: item.stock - item.quantity,
        operatorId: req.user!.id,
        operatorName: operator?.name || '未知',
        purpose: claim.purpose || null,
        customerName: claim.customer_name || null,
        remark: remark || null,
        refId: outboundId as number,
      })
    }
    db.prepare("UPDATE claims SET status = 'confirmed' WHERE id = ?").run(id)
  })
  tx()
  res.json({ success: true })
})

export default router
