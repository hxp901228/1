import { Router, type Request, type Response } from 'express'
import bcrypt from 'bcryptjs'
import { db } from '../db.js'
import { signToken, authMiddleware, type AuthRequest } from '../middleware/auth.js'

const router = Router()

router.post('/login', (req: Request, res: Response): void => {
  const { username, password } = req.body
  if (!username || !password) {
    res.status(400).json({ success: false, error: '请输入账号和密码' })
    return
  }
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username) as any
  if (!user) {
    res.status(401).json({ success: false, error: '账号或密码错误' })
    return
  }
  if (user.disabled) {
    res.status(403).json({ success: false, error: '账号已被禁用' })
    return
  }
  const valid = bcrypt.compareSync(password, user.password)
  if (!valid) {
    res.status(401).json({ success: false, error: '账号或密码错误' })
    return
  }
  const token = signToken({ id: user.id, username: user.username, name: user.name, role: user.role })
  res.json({
    success: true,
    token,
    user: { id: user.id, username: user.username, name: user.name, role: user.role },
  })
})

router.get('/me', authMiddleware, (req: AuthRequest, res: Response): void => {
  res.json({ success: true, user: req.user })
})

export default router
