import { Router, type Response } from 'express'
import { db, logOperation } from '../db.js'
import { authMiddleware, requireAdmin, type AuthRequest } from '../middleware/auth.js'

const router = Router()

router.use(authMiddleware, requireAdmin)

router.get('/', (req: AuthRequest, res: Response): void => {
  const rows = db.prepare(`
    SELECT o.*, u.name as operator_name, c.purpose, c.customer_name
    FROM outbounds o
    JOIN users u ON o.operator_id = u.id
    LEFT JOIN claims c ON o.claim_id = c.id
    ORDER BY o.created_at DESC
  `).all()
  for (const outbound of rows as any[]) {
    outbound.items = db.prepare(`
      SELECT oi.*, p.name as product_name, p.image, p.spec
      FROM outbound_items oi
      JOIN products p ON oi.product_id = p.id
      WHERE oi.outbound_id = ?
    `).all(outbound.id)
  }
  res.json({ success: true, data: rows })
})

router.post('/', (req: AuthRequest, res: Response): void => {
  const { productId, quantity, remark } = req.body
  if (!productId || !quantity || quantity <= 0) {
    res.status(400).json({ success: false, error: '请选择产品和出库数量' })
    return
  }
  const product = db.prepare('SELECT name, spec, stock FROM products WHERE id = ?').get(productId) as any
  if (!product) {
    res.status(400).json({ success: false, error: '产品不存在' })
    return
  }
  if (product.stock < quantity) {
    res.status(400).json({ success: false, error: '库存不足' })
    return
  }

  const operator = db.prepare('SELECT name FROM users WHERE id = ?').get(req.user!.id) as { name: string } | undefined

  const tx = db.transaction(() => {
    const result = db.prepare(
      'INSERT INTO outbounds (remark, operator_id, type) VALUES (?, ?, ?)'
    ).run(remark || null, req.user!.id, 'direct')
    const outboundId = result.lastInsertRowid
    db.prepare(
      'INSERT INTO outbound_items (outbound_id, product_id, quantity) VALUES (?, ?, ?)'
    ).run(outboundId, productId, quantity)
    db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(quantity, productId)

    logOperation({
      operationType: 'outbound',
      productId,
      productName: product.name,
      spec: product.spec,
      quantity,
      stockBefore: product.stock,
      stockAfter: product.stock - quantity,
      operatorId: req.user!.id,
      operatorName: operator?.name || '未知',
      remark: remark || null,
      refId: outboundId as number,
    })
  })
  tx()
  res.json({ success: true })
})

router.put('/:outboundId/items/:itemId/revoke', (req: AuthRequest, res: Response): void => {
  const itemId = Number(req.params.itemId)
  const item = db.prepare('SELECT * FROM outbound_items WHERE id = ?').get(itemId) as any
  if (!item) {
    res.status(404).json({ success: false, error: '出库项不存在' })
    return
  }
  if (item.revoked) {
    res.status(400).json({ success: false, error: '该出库项已撤销' })
    return
  }
  const product = db.prepare('SELECT name, spec, stock FROM products WHERE id = ?').get(item.product_id) as any
  const operator = db.prepare('SELECT name FROM users WHERE id = ?').get(req.user!.id) as { name: string } | undefined
  const stockBefore = product?.stock || 0

  const tx = db.transaction(() => {
    db.prepare('UPDATE outbound_items SET revoked = 1 WHERE id = ?').run(itemId)
    db.prepare('UPDATE products SET stock = stock + ? WHERE id = ?').run(item.quantity, item.product_id)

    logOperation({
      operationType: 'revoke_outbound',
      productId: item.product_id,
      productName: product?.name || '未知产品',
      spec: product?.spec || null,
      quantity: item.quantity,
      stockBefore,
      stockAfter: stockBefore + item.quantity,
      operatorId: req.user!.id,
      operatorName: operator?.name || '未知',
      remark: `撤销出库 #${item.outbound_id}`,
      refId: item.outbound_id,
    })
  })
  tx()
  res.json({ success: true })
})

export default router
