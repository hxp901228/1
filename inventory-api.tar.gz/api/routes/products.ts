import { Router, type Response } from 'express'
import { db, logOperation } from '../db.js'
import { authMiddleware, requireAdmin, type AuthRequest } from '../middleware/auth.js'

const router = Router()

router.use(authMiddleware)

// 获取产品列表（默认排除已删除）
router.get('/', (req: AuthRequest, res: Response): void => {
  const q = (req.query.q as string) || ''
  const includeDeleted = req.query.includeDeleted === '1'
  let sql = 'SELECT * FROM products WHERE 1=1'
  const params: any[] = []
  if (!includeDeleted) {
    sql += ' AND deleted = 0'
  }
  if (q) {
    sql += ' AND name LIKE ?'
    params.push(`%${q}%`)
  }
  sql += ' ORDER BY created_at DESC'
  const products = db.prepare(sql).all(...params)
  res.json({ success: true, data: products })
})

router.get('/:id', (req: AuthRequest, res: Response): void => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(Number(req.params.id))
  if (!product) {
    res.status(404).json({ success: false, error: '产品不存在' })
    return
  }
  res.json({ success: true, data: product })
})

// 修改产品（库存调整）- 仅管理员/开发者
router.put('/:id', requireAdmin, (req: AuthRequest, res: Response): void => {
  const id = Number(req.params.id)
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as any
  if (!product) {
    res.status(404).json({ success: false, error: '产品不存在' })
    return
  }

  const { name, spec, batch_no, production_date, expiry_date, stock, source, remark, image } = req.body

  const oldStock = product.stock
  const newStock = stock !== undefined ? Number(stock) : oldStock

  const tx = db.transaction(() => {
    db.prepare(
      `UPDATE products SET
        name = COALESCE(?, name),
        spec = COALESCE(?, spec),
        batch_no = COALESCE(?, batch_no),
        production_date = COALESCE(?, production_date),
        expiry_date = COALESCE(?, expiry_date),
        stock = COALESCE(?, stock),
        source = COALESCE(?, source),
        remark = COALESCE(?, remark),
        image = COALESCE(?, image)
       WHERE id = ?`
    ).run(
      name ?? null,
      spec ?? null,
      batch_no ?? null,
      production_date ?? null,
      expiry_date ?? null,
      newStock,
      source ?? null,
      remark ?? null,
      image ?? null,
      id
    )

    // 库存有变化时记录日志（仅记录当前状态变更，不修改历史日志）
    if (newStock !== oldStock) {
      logOperation({
        operationType: 'adjust',
        productId: id,
        productName: name || product.name,
        spec: spec || product.spec,
        quantity: newStock - oldStock,
        stockBefore: oldStock,
        stockAfter: newStock,
        operatorId: req.user!.id,
        operatorName: req.user!.name,
        source: '库存调整',
        remark: remark || '库存调整',
      })
    }
  })

  tx()

  const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(id)
  res.json({ success: true, data: updated })
})

// 删除产品（软删除）- 仅管理员/开发者
router.delete('/:id', requireAdmin, (req: AuthRequest, res: Response): void => {
  const id = Number(req.params.id)
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as any
  if (!product) {
    res.status(404).json({ success: false, error: '产品不存在' })
    return
  }

  db.prepare('UPDATE products SET deleted = 1 WHERE id = ?').run(id)
  res.json({ success: true, message: '产品已删除' })
})

export default router
