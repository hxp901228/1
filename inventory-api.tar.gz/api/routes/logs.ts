import { Router, type Response } from 'express'
import { db } from '../db.js'
import { authMiddleware, requireAdmin, type AuthRequest } from '../middleware/auth.js'

const router = Router()

router.use(authMiddleware, requireAdmin)

router.get('/', (req: AuthRequest, res: Response): void => {
  const type = (req.query.type as string) || 'all'
  const startDate = req.query.startDate as string | undefined
  const endDate = req.query.endDate as string | undefined
  let sql = 'SELECT * FROM operation_logs WHERE 1=1'
  const params: any[] = []
  if (type !== 'all') {
    sql += ' AND operation_type = ?'
    params.push(type)
  }
  if (startDate) {
    sql += ' AND created_at >= ?'
    params.push(startDate)
  }
  if (endDate) {
    sql += ' AND created_at <= ?'
    params.push(`${endDate} 23:59:59`)
  }
  sql += ' ORDER BY created_at DESC'
  const rows = db.prepare(sql).all(...params)
  res.json({ success: true, data: rows })
})

export default router
