import { Router, type Response } from 'express'
import bcrypt from 'bcryptjs'
import { db } from '../db.js'
import { authMiddleware, requireAdmin, type AuthRequest } from '../middleware/auth.js'

const router = Router()

router.use(authMiddleware, requireAdmin)

router.get('/', (req: AuthRequest, res: Response): void => {
  const users = db.prepare(
    'SELECT id, username, name, role, disabled, created_at FROM users ORDER BY created_at DESC'
  ).all()
  res.json({ success: true, data: users })
})

router.post('/', (req: AuthRequest, res: Response): void => {
  const { username, password, name, role } = req.body
  if (!username || !password || !name) {
    res.status(400).json({ success: false, error: '请填写账号、密码和姓名' })
    return
  }
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username)
  if (existing) {
    res.status(400).json({ success: false, error: '账号已存在' })
    return
  }
  const hash = bcrypt.hashSync(password, 10)
  const result = db.prepare(
    'INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)'
  ).run(username, hash, name, role || 'employee')
  res.json({ success: true, data: { id: result.lastInsertRowid } })
})

router.put('/:id', (req: AuthRequest, res: Response): void => {
  const id = Number(req.params.id)
  const { name, password, disabled, role } = req.body
  const fields: string[] = []
  const values: any[] = []
  if (name !== undefined) { fields.push('name = ?'); values.push(name) }
  if (password) { fields.push('password = ?'); values.push(bcrypt.hashSync(password, 10)) }
  if (disabled !== undefined) { fields.push('disabled = ?'); values.push(disabled ? 1 : 0) }
  if (role !== undefined) { fields.push('role = ?'); values.push(role) }
  if (fields.length === 0) {
    res.json({ success: true })
    return
  }
  values.push(id)
  db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`).run(...values)
  res.json({ success: true })
})

router.delete('/:id', (req: AuthRequest, res: Response): void => {
  const id = Number(req.params.id)
  if (id === req.user!.id) {
    res.status(400).json({ success: false, error: '不能删除自己' })
    return
  }
  db.prepare('DELETE FROM users WHERE id = ?').run(id)
  res.json({ success: true })
})

export default router
