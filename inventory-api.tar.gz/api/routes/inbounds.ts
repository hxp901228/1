import { Router, type Response } from 'express'
import { db, logOperation } from '../db.js'
import { authMiddleware, requireAdmin, type AuthRequest } from '../middleware/auth.js'

const router = Router()

router.use(authMiddleware, requireAdmin)

router.get('/', (req: AuthRequest, res: Response): void => {
  const rows = db.prepare(`
    SELECT i.*, p.name as product_name, p.spec, p.batch_no, p.image, u.name as operator_name
    FROM inbounds i
    JOIN products p ON i.product_id = p.id
    JOIN users u ON i.operator_id = u.id
    ORDER BY i.created_at DESC
  `).all()
  res.json({ success: true, data: rows })
})

router.post('/', (req: AuthRequest, res: Response): void => {
  const { productName, images, spec, batchNo, productionDate, expiryDate, quantity, source, remark, productId } = req.body
  if (!productName || !quantity || quantity <= 0) {
    res.status(400).json({ success: false, error: '请填写产品名称和入库数量' })
    return
  }

  const imageStr = Array.isArray(images) && images.length > 0
    ? JSON.stringify(images.slice(0, 3))
    : null

  const operator = db.prepare('SELECT name FROM users WHERE id = ?').get(req.user!.id) as { name: string } | undefined

  const tx = db.transaction(() => {
    let pid = productId
    let stockBefore = 0
    let productNameFinal = productName
    let productSpec = spec || null
    if (pid) {
      // 合并已有图片与新上传图片（最多3张）
      const existing = db.prepare('SELECT image, name, spec, stock FROM products WHERE id = ?').get(pid) as any
      stockBefore = existing?.stock || 0
      productNameFinal = existing?.name || productName
      productSpec = spec || existing?.spec || null
      let merged: string[] = []
      try {
        if (existing?.image) {
          const arr = JSON.parse(existing.image)
          if (Array.isArray(arr)) merged = arr
        }
      } catch { /* ignore */ }
      if (Array.isArray(images)) {
        merged = [...merged, ...images].slice(0, 3)
      }
      const finalImage = merged.length > 0 ? JSON.stringify(merged) : existing?.image || null
      db.prepare(
        `UPDATE products SET stock = stock + ?,
          spec = COALESCE(?, spec),
          batch_no = COALESCE(?, batch_no),
          production_date = COALESCE(?, production_date),
          expiry_date = COALESCE(?, expiry_date),
          image = COALESCE(?, image)
         WHERE id = ?`
      ).run(quantity, spec || null, batchNo || null, productionDate || null, expiryDate || null, finalImage, pid)
    } else {
      const result = db.prepare(
        `INSERT INTO products (name, image, spec, batch_no, production_date, expiry_date, stock, source, remark)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(productName, imageStr, spec || null, batchNo || null, productionDate || null, expiryDate || null, quantity, source || null, remark || null)
      pid = result.lastInsertRowid
      stockBefore = 0
    }
    const inboundResult = db.prepare(
      'INSERT INTO inbounds (product_id, quantity, source, remark, operator_id) VALUES (?, ?, ?, ?, ?)'
    ).run(pid, quantity, source || null, remark || null, req.user!.id)

    logOperation({
      operationType: 'inbound',
      productId: pid as number,
      productName: productNameFinal,
      spec: productSpec,
      quantity,
      stockBefore,
      stockAfter: stockBefore + quantity,
      operatorId: req.user!.id,
      operatorName: operator?.name || '未知',
      source: source || null,
      remark: remark || null,
      refId: inboundResult.lastInsertRowid as number,
    })
  })
  tx()
  res.json({ success: true })
})

export default router
