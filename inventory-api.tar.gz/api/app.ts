import express, {
  type Request,
  type Response,
  type NextFunction,
} from 'express'
import cors from 'cors'
import path from 'path'
import dotenv from 'dotenv'
import { fileURLToPath } from 'url'
import authRoutes from './routes/auth.js'
import usersRoutes from './routes/users.js'
import productsRoutes from './routes/products.js'
import inboundsRoutes from './routes/inbounds.js'
import claimsRoutes from './routes/claims.js'
import outboundsRoutes from './routes/outbounds.js'
import recordsRoutes from './routes/records.js'
import logsRoutes from './routes/logs.js'
import uploadRoutes from './routes/upload.js'
import { initDatabase } from './db.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

dotenv.config()

initDatabase()

const app: express.Application = express()

app.use(cors())
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true, limit: '10mb' }))

app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')))

app.use('/api/auth', authRoutes)
app.use('/api/users', usersRoutes)
app.use('/api/products', productsRoutes)
app.use('/api/inbounds', inboundsRoutes)
app.use('/api/claims', claimsRoutes)
app.use('/api/outbounds', outboundsRoutes)
app.use('/api/records', recordsRoutes)
app.use('/api/logs', logsRoutes)
app.use('/api/upload', uploadRoutes)

app.use(
  '/api/health',
  (req: Request, res: Response, next: NextFunction): void => {
    res.status(200).json({ success: true, message: 'ok' })
  },
)

app.use((error: Error, req: Request, res: Response, next: NextFunction) => {
  console.error(error)
  res.status(500).json({ success: false, error: '服务器内部错误' })
})

app.use((req: Request, res: Response) => {
  res.status(404).json({ success: false, error: 'API not found' })
})

export default app
